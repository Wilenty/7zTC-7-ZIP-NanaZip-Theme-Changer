
    
   Windows 10 7-Zip theme

   -------------------------------------------

   Toolbar and icons FileType for 7-Zip

   Blue color and Default color

   ----------------------------------------

   Rename - .ex_ in - .exe

   or

   Run - Rename All to EXE.bat

   -----------------------------------------------------------

   Used 7zTM 2.1 or 7zTM 2.1.1 depending on the version 7-Zip

   this in order to avoid errors

   -----------------------------------------------------------

   http://alexgal23.deviantart.com/
